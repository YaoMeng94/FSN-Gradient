function  data = tril2vec(Source)
% Extract the lower triangle (diag not included), place as column by column 
data=[ ];
for i=1:size(Source,1)-1
    data = [data; Source(i+1:end,i)];
end